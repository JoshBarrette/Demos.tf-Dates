# Real Dates for Demos.tf

## How to install

1.  Go to the extensions tab in chrome
2.  Enable Developer Mode by clicking the toggle switch in the top right
3.  Click "Load Unpacked" in the top left
4.  Select the root directory of the extension (the file that contains manifest.json)

Done :)

## Preview

<img src="https://i.imgur.com/beHb6Vd.png">
